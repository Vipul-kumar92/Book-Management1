import React from 'react';
import bookImage from './book1.jph_files/the-making-of-a-manager-book-01-1-2048x1152.jpeg';

const Home = () => {
  return (
    <div>
      <img src={bookImage} alt='' width={1450} height={800}/>
    </div>
  );
}

export default Home;

